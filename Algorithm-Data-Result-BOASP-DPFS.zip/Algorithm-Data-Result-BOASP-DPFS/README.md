Instances and results for BOASP-DPFS
